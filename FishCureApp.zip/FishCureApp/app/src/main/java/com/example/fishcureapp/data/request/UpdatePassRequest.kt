package com.example.fishcureapp.data.request

data class UpdatePassRequest (
    val email: String,
    val newPassword: String
)