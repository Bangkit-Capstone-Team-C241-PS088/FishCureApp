package com.example.fishcureapp.ui.camera

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.fishcureapp.R

class CameraActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_camera)
    }
}