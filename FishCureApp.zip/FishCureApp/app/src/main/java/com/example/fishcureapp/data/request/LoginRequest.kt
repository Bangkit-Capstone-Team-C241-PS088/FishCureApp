package com.example.fishcureapp.data.request

data class LoginRequest(
    val email: String,
    val password: String)