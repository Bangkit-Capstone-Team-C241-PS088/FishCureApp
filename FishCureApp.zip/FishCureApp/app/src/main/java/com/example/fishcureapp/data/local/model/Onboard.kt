package com.example.fishcureapp.data.local.model

data class Onboard(
    val img:Int,
    val description:String,
)
