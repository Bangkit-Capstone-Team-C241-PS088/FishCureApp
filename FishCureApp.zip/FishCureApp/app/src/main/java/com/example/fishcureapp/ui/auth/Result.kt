package com.example.fishcureapp.ui.auth

data class Result(val success: Boolean, val error: String? = null)