package com.example.fishcureapp.data.request

data class AuthOtpRequest (
    val email: String,
    val otp: String
)