package com.example.fishcureapp.data.request

data class RegisterRequest (
    val email: String,
    val password: String

)