package com.example.fishcureapp.data.request

data class SendOtpRequest (
    val email: String,
)