package com.example.fishcureapp.data.local.model

data class User (

    val email: String,
    val isLogin: Boolean
)

