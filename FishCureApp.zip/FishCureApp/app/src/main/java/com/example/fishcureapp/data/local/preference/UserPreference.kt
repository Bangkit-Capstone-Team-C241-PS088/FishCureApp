package com.example.fishcureapp.data.local.preference

class UserPreference {
}